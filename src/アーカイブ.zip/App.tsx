import React, { useEffect, useState } from 'react';

// --- 共通設定 ---
// ★ あなたのCloud RunのURL
const API_BASE_URL = 'https://hackathon-backend-1093557143473.us-central1.run.app';

// --- コンポーネント: AI商品説明生成 ---
const AiGenerator: React.FC = () => {
    const [productName, setProductName] = useState('');
    const [description, setDescription] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState('');

    const handleGenerateDescription = async () => {
        if (!productName) {
            setError('商品名を入力してください。');
            return;
        }

        setError('');
        setIsLoading(true);
        setDescription('');

        try {
            const response = await fetch(`${API_BASE_URL}/generate-description`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ productName }),
            });

            if (!response.ok) {
                throw new Error(`API呼び出しエラー: ${response.status}`);
            }

            const data = await response.json();
            setDescription(data.description);
        } catch (err: any) {
            console.error('説明文生成エラー:', err);
            setError('説明文の生成に失敗しました。');
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div style={{ marginBottom: '30px', padding: '20px', border: '1px solid #4caf50', borderRadius: '8px', backgroundColor: '#333', textAlign: 'center' }}>
            <h2 style={{ color: '#4caf50' }}>🤖 AI 商品説明ジェネレーター</h2>
            <p style={{ fontSize: '0.9em', color: '#ccc' }}>
                商品名を入力すると、AIが説明文を生成します。
            </p>

            <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', gap: '10px', margin: '15px 0' }}>
                <input
                    type="text"
                    value={productName}
                    onChange={(e) => {
                        setProductName(e.target.value);
                        if (error) setError('');
                    }}
                    placeholder="例: おしゃれなTシャツ"
                    style={{ padding: '8px', borderRadius: '4px', border: '1px solid #ccc', width: '250px' }}
                    disabled={isLoading}
                />
                <button
                    onClick={handleGenerateDescription}
                    disabled={isLoading || !productName}
                    style={{
                        padding: '8px 16px',
                        borderRadius: '4px',
                        border: 'none',
                        backgroundColor: isLoading ? '#ccc' : '#4caf50',
                        color: 'white',
                        cursor: isLoading ? 'not-allowed' : 'pointer',
                    }}
                >
                    {isLoading ? '生成中...' : '生成'}
                </button>
            </div>

            {error && (
                <p style={{ color: '#ff6b6b', fontSize: '0.9em' }}>{error}</p>
            )}

            {description && (
                <div style={{ marginTop: '15px', padding: '15px', backgroundColor: '#444', borderRadius: '8px', textAlign: 'left' }}>
                    <h3 style={{ fontSize: '1em', color: '#fff', marginBottom: '5px' }}>生成された説明文:</h3>
                    <p style={{ fontSize: '0.95em', color: '#ddd', whiteSpace: 'pre-wrap', lineHeight: '1.5' }}>
                        {description}
                    </p>
                </div>
            )}
        </div>
    );
};

// --- 型定義 ---
interface User {
    id: string;
    name: string;
    age: number;
}

interface Item {
    id: string;
    name: string;
    price: number;
    description: string;
    sold_out: boolean;
}

// --- メインコンポーネント: App ---
function App() {
    // --- ユーザー関連のState ---
    const [users, setUsers] = useState<User[]>([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');

    // 登録用フォームの状態管理
    const [nameInput, setNameInput] = useState('');
    const [ageInput, setAgeInput] = useState('');

    // --- 商品関連のState ---
    const [items, setItems] = useState<Item[]>([]);
    const [itemLoading, setItemLoading] = useState(false);

    // ユーザー検索関数
    const searchUser = async (searchName: string) => {
        if (!searchName) return;
        setLoading(true);
        setError('');
        try {
            const response = await fetch(`${API_BASE_URL}/user?name=${searchName}`);
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            const data = await response.json();
            setUsers(data);
        } catch (e: any) {
            setError(e.message);
            setUsers([]);
        } finally {
            setLoading(false);
        }
    };

    // 初回ロード時に "hanako" を検索し、商品一覧も取得
    useEffect(() => {
        searchUser('hanako');
        fetchItems();
    }, []);

    // ユーザー登録関数
    const registerUser = async () => {
        if (!nameInput || !ageInput) {
            alert('名前と年齢を入力してください');
            return;
        }

        const age = parseInt(ageInput, 10);
        if (isNaN(age)) {
            alert('年齢は数字で入力してください');
            return;
        }

        try {
            const response = await fetch(`${API_BASE_URL}/user`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ name: nameInput, age: age }),
            });

            if (!response.ok) {
                throw new Error(`登録失敗: ${response.status}`);
            }

            alert('登録しました！');
            searchUser(nameInput);
            setNameInput('');
            setAgeInput('');

        } catch (e: any) {
            alert(`エラー: ${e.message}`);
        }
    };

    // 商品一覧取得関数
    const fetchItems = async () => {
        setItemLoading(true);
        try {
            const response = await fetch(`${API_BASE_URL}/items`);
            if (!response.ok) throw new Error('商品一覧の取得に失敗しました');
            const data = await response.json();
            setItems(data);
        } catch (e: any) {
            console.error(e);
        } finally {
            setItemLoading(false);
        }
    };

    // 商品購入関数
    const purchaseItem = async (itemId: string) => {
        const confirmPurchase = window.confirm('この商品を購入しますか？');
        if (!confirmPurchase) return;

        try {
            const response = await fetch(`${API_BASE_URL}/items/purchase?id=${itemId}`, {
                method: 'POST',
            });

            if (!response.ok) throw new Error('購入に失敗しました');

            alert('購入しました！');
            fetchItems(); // 一覧を更新して売り切れ表示にする
        } catch (e: any) {
            alert(e.message);
        }
    };

    return (
        <div style={{ textAlign: 'center', backgroundColor: '#282c34', minHeight: '100vh', color: 'white', padding: '20px' }}>
            <header style={{ maxWidth: '800px', margin: '0 auto' }}>
                <h1>ハッカソン・アプリ</h1>

                {/* AI生成コンポーネント */}
                <AiGenerator />
                <br />

                {/* 商品一覧エリア */}
                <div style={{ marginBottom: '30px', padding: '20px', border: '1px solid #ff9800', borderRadius: '8px', backgroundColor: '#333' }}>
                    <h2>🛍️ 商品一覧</h2>
                    <button onClick={fetchItems} style={{ marginBottom: '15px', padding: '5px 10px', cursor: 'pointer' }}>一覧を更新</button>

                    {itemLoading ? <p>読み込み中...</p> : (
                        <div style={{ display: 'flex', flexWrap: 'wrap', justifyContent: 'center', gap: '20px' }}>
                            {items.map((item) => (
                                <div key={item.id} style={{ border: '1px solid white', padding: '15px', borderRadius: '8px', width: '220px', backgroundColor: item.sold_out ? '#555' : '#444', opacity: item.sold_out ? 0.7 : 1 }}>
                                    <h3>{item.name}</h3>
                                    <p style={{ fontSize: '1.2em', fontWeight: 'bold', color: '#ffd700' }}>¥{item.price}</p>
                                    <p style={{ fontSize: '0.9em', height: '40px', overflow: 'hidden' }}>{item.description}</p>

                                    {item.sold_out ? (
                                        <p style={{ color: 'red', fontWeight: 'bold', border: '2px solid red', padding: '5px', display: 'inline-block' }}>SOLD OUT</p>
                                    ) : (
                                        <button onClick={() => purchaseItem(item.id)} style={{ backgroundColor: '#ff9800', color: 'white', border: 'none', padding: '8px 16px', cursor: 'pointer', borderRadius: '4px' }}>
                                            購入する
                                        </button>
                                    )}
                                </div>
                            ))}
                        </div>
                    )}
                </div>

                {/* 登録フォームエリア */}
                <div style={{ marginBottom: '20px', padding: '20px', border: '1px solid #61dafb', borderRadius: '8px' }}>
                    <h3>新規ユーザー登録</h3>
                    <input
                        type="text"
                        placeholder="名前"
                        value={nameInput}
                        onChange={(e) => setNameInput(e.target.value)}
                        style={{ margin: '5px', padding: '5px' }}
                    />
                    <input
                        type="number"
                        placeholder="年齢"
                        value={ageInput}
                        onChange={(e) => setAgeInput(e.target.value)}
                        style={{ margin: '5px', padding: '5px' }}
                    />
                    <button onClick={registerUser} style={{ padding: '5px 10px', cursor: 'pointer' }}>登録</button>
                </div>

                {/* 検索・表示エリア */}
                <div style={{ marginBottom: '20px' }}>
                    <button onClick={() => searchUser('hanako')} style={{marginRight: '10px', padding: '5px 10px', cursor: 'pointer'}}>hanakoを検索</button>
                    <button onClick={() => searchUser('taro')} style={{padding: '5px 10px', cursor: 'pointer'}}>taroを検索</button>
                </div>

                {loading && <p>読み込み中...</p>}
                {error && <p style={{ color: 'red' }}>エラーが発生しました: {error}</p>}

                <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                    {users.map((user) => (
                        <div key={user.id} style={{ border: '1px solid white', margin: '10px', padding: '10px', borderRadius: '8px', width: '300px' }}>
                            <h2>名前: {user.name}</h2>
                            <p>年齢: {user.age}歳</p>
                            <p style={{ fontSize: '0.8em', color: '#ccc' }}>ID: {user.id}</p>
                        </div>
                    ))}
                </div>

                {!loading && !error && users.length === 0 && (
                    <p>データが見つかりませんでした。</p>
                )}
            </header>
        </div>
    );
}

export default App;