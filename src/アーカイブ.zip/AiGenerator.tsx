// src/AiGenerator.tsx
import React, { useState } from 'react';

const AiGenerator = () => {
    const [productName, setProductName] = useState("");
    const [description, setDescription] = useState("");
    const [loading, setLoading] = useState(false);

    const handleGenerate = async () => {
        if (!productName) return;
        setLoading(true);
        setDescription("");

        try {
            // ローカルで動いているGoサーバー(8080)にAI生成を依頼
            const response = await fetch("http://localhost:8080/api/generate", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ product_name: productName }),
            });

            if (!response.ok) throw new Error("Network response was not ok");
            const data = await response.json();
            setDescription(data.description);
        } catch (error) {
            console.error(error);
            setDescription("エラー：バックエンド(main.go)が起動しているか確認してください");
        } finally {
            setLoading(false);
        }
    };

    return (
        <div style={{ marginTop: '30px', padding: '20px', border: '1px solid #ff00ff', borderRadius: '8px', background: '#202020', width: '80%', maxWidth: '500px' }}>
            <h3 style={{ color: '#ff00ff' }}>✨ AI商品説明ジェネレーター</h3>
            <div style={{ display: 'flex', gap: '10px', marginBottom: '15px' }}>
                <input
                    type="text"
                    placeholder="商品名（例：魔法の杖）"
                    value={productName}
                    onChange={(e) => setProductName(e.target.value)}
                    style={{ flex: 1, padding: '8px', borderRadius: '4px', border: 'none' }}
                />
                <button
                    onClick={handleGenerate}
                    disabled={loading}
                    style={{
                        padding: '8px 16px',
                        background: '#ff00ff',
                        color: 'white',
                        border: 'none',
                        borderRadius: '4px',
                        cursor: loading ? 'wait' : 'pointer'
                    }}
                >
                    {loading ? "..." : "作成"}
                </button>
            </div>

            {description && (
                <div style={{ background: '#333', padding: '15px', borderRadius: '5px', textAlign: 'left', lineHeight: '1.6' }}>
                    <strong>AIの提案:</strong><br/>
                    {description}
                </div>
            )}
        </div>
    );
};

export default AiGenerator;